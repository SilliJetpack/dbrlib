const snek = require("snekfetch")

const url = "https://discordbotsreview.tk/api/bot/"
const url2 = "https://discordbotsreview.tk/api/user/"

module.exports.dbrbot = class {
     
async getbot(clientID) {

    const ass = await snek.get(url + clientID)
    const options = {
        clientID: ass.body["clientID"],
        prefix: ass.body["prefix"],
        invite_url: ass.body["invite_url"],
        support_url: ass.body["support_url"],
        short_description: ass.body["short_description"],
        long_description: ass.body["long_description"],
        ownerID: ass.body["owner"]["id"],
        ownerBIO: ass.body["owner"]["bio"],
        ownerCERTIFIED: ass.body["owner"]["certified"],
        likes: ass.body["likes"],
        dislikes: ass.body["dislikes"],
        unique: ass.body["unique"],
        veryUnique: ass.body["veryUnique"]
    }
 return options
}
async getuser(userID) {
    const ass = await snek.get(url2 + userID)
    const options = {
        id: ass.body["id"],
        biography: ass.body["bio"],
        iscertified: ass.body["certified"],
        bots: ass.body["bots"]
    }
    return options
}
}

