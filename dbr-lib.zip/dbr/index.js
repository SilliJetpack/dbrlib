const snek = require("snekfetch")
const fs = require("fs")
const url = "https://discordbotsreview.tk/api/bot/"
const url2 = "https://discordbotsreview.tk/api/user/"
const url3 = "https://discordbotsreview.tk/api/widget/"
const url4 = "https://discordbotsreview.tk/api/bot/"

module.exports.dbrbot = class {
     
async getbot(clientID) {

    const ass = await snek.get(url + clientID)
    const options = {
        clientID: ass.body["clientID"],
        prefix: ass.body["prefix"],
        invite_url: ass.body["invite_url"],
        support_url: ass.body["support_url"],
        short_description: ass.body["short_description"],
        long_description: ass.body["long_description"],
        ownerID: ass.body["owner"]["id"],
        ownerBIO: ass.body["owner"]["bio"],
        ownerCERTIFIED: ass.body["owner"]["certified"],
        likes: ass.body["likes"],
        dislikes: ass.body["dislikes"],
        unique: ass.body["unique"],
        veryUnique: ass.body["veryUnique"]
    }
 return options
}
async getuser(userID) {
    const ass = await snek.get(url2 + userID)
    const options = {
        id: ass.body["id"],
        biography: ass.body["bio"],
        iscertified: ass.body["certified"],
        bots: ass.body["bots"]
    }
    
    return options
}
async getwidget(botID, dir) {
    const ass = await snek.get(url3 + botID + ".png")
        fs.writeFile(dir + ".png", ass.body, function(err) {
        });
   
    }
    async post(botID, token, servercount) {
snek.post(url4 + botID + "/stats")
.set("Authorization", token)
.send({server_count: servercount})
.end()
    }
}

