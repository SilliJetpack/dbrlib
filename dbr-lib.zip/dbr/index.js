const snek = require("snekfetch")
const fs = require("fs")
const url = "https://discordbotsreview.tk/api/bot/"
const url2 = "https://discordbotsreview.tk/api/user/"
const url3 = "https://discordbotsreview.tk/api/widget/"
const url4 = "https://discordbotsreview.tk/api/bot/"

module.exports.dbrbot = class {
     
async getbot(clientID) {
    if(!clientID) throw new Error("Client ID must be specified.")

    const ass = await snek.get(url + clientID)
    const options = {
        clientID: ass.body["clientID"],
        prefix: ass.body["prefix"],
        invite_url: ass.body["invite_url"],
        support_url: ass.body["support_url"],
        short_description: ass.body["short_description"],
        long_description: ass.body["long_description"],
        ownerID: ass.body["owner"]["id"],
        ownerBIO: ass.body["owner"]["bio"],
        ownerCERTIFIED: ass.body["owner"]["certified"],
        likes: ass.body["likes"],
        dislikes: ass.body["dislikes"],
        unique: ass.body["unique"],
        veryUnique: ass.body["veryUnique"],
        source: ass.body["source"],
        server_count: ass.body["servers"]
    }
 return options
}
async getuser(userID) {
    if(!userID) throw new Error("User ID must be specified.")

    const ass = await snek.get(url2 + userID)
    const options = {
        id: ass.body["id"],
        biography: ass.body["bio"] === null ? "none" : ass.body["bio"],
        iscertified: ass.body["certified"],
        bots: ass.body["bots"],
        website: ass.body["website"] === undefined ? "none" : ass.body["website"],
        background_image: ass.body["background"] === undefined ? "none" : ass.body["background"],
        pulse_color: ass.body["pulsecolor"] === undefined ? "none" : ass.body["pulsecolor"],
        certified_bots: ass.body["certifiedbots"],
        animation_time: ass.body["animationtime"] === undefined ? "none" : ass.body["animationtime"]
    }
    
    return options
}
async getwidget(botID, dir, type, style) {
    if(!botID) throw new Error("Bot ID must be specified.")
    const lol = type === "alt" ? url3 + "2/" + botID + ".png" : url3 + botID + ".png"
    var options;
    if(style) {
         options = [
            style.header1 ===  undefined ? "" : style.header1 = "header1=" + style.header1 + "&",
        style.header2 === undefined ? "" : style.header2 = "header2=" + style.header2 + "&",
        style.body === undefined ? "" : style.body = "body=" + style.body + "&",
        style.removeowneravatar === undefined ? "" : style.removeowneravatar = "removeowneravatar=" + style.removeowneravatar + "&",
        style.hideicon === undefined ? "" : style.hideicon = "hideicon=" + style.hideicon + "&",
        style.hidelikes === undefined ? "" : style.hidelikes = "hidelikes=" + style.hidelikes + "&",
        style.hidedislikes === undefined ? "" : style.hidedislikes = "hidedislikes=" + style.hidedislikes + "&",
        style.hidecomments === undefined ? "" : style.hidecomments = "hidecomments=" + style.hidecomments + "&",
        style.hideservers === undefined ? "" : style.hideservers = "hideservers=" + style.hideservers + "&",
        style.gradient1 === undefined ? "" : style.gradient1 = "gradient1=" + style.gradient1 + "&",
        style.gradient2 === undefined ? "" : style.gradient2 = "gradient2=" + style.gradient2 + "&"

        ]
    } else options = null
    const lmao = options === null ? "" : "?" + options.join('')
    const ass = await snek.get(lol + lmao)
        fs.writeFile(dir + ".png", ass.body, function(err) {
        });
   
    }
    async post(botID, token, servercount) {
        if(!botID) throw new Error("Bot ID must be specified.")
        if(!token) throw new Error("Token must be specified.")
        if(!servercount) throw new Error("Server count must be specified.")
        if(isNaN(servercount)) throw new Error("Server count must be a number.")
snek.post(url4 + botID + "/stats")
.set("Authorization", token)
.send({server_count: servercount})
.end()
    }
}

